$(document).ready(function()
{
	$(".btn1").hover(function(){
		$(".btn1").addClass("over")
	},
	function(){
			$(".btn1").removeClass('over')
	});

	$(".btn2").hover(function(){
		$(".btn2").addClass("over")
	},
	function(){
			$(".btn2").removeClass('over')
	});
	$(".btn3").hover(function(){
		$(".btn3").addClass("over")
	},
	function(){
			$(".btn3").removeClass('over')
	});	

	$(".btn4").hover(function(){
		$(".btn4").addClass("over")
	},
	function(){
			$(".btn4").removeClass('over')
	});
	
	$(".btn5").hover(function(){
		$(".btn5").addClass("over")
	},
	function(){
			$(".btn5").removeClass('over')
	});	

	$(".btn6").hover(function(){
		$(".btn6").addClass("over")
	},
	function(){
			$(".btn6").removeClass('over')
	});

	$(".btn7").hover(function(){
		$(".btn7").addClass("over")
	},
	function(){
			$(".btn7").removeClass('over')
	});

	$(".btn8").hover(function(){
		$(".btn8").addClass("over")
	},
	function(){
			$(".btn8").removeClass('over')
	});

	$(".btn9").hover(function(){
		$(".btn9").addClass("over")
	},
	function(){
			$(".btn9").removeClass('over')
	});

	$(".btn10").hover(function(){
		$(".btn10").addClass("over")
	},
	function(){
			$(".btn10").removeClass('over')
	});

	$(".btn11").hover(function(){
		$(".btn11").addClass("over")
	},
	function(){
			$(".btn11").removeClass('over')
	});

	$(".btn12").hover(function(){
		$(".btn12").addClass("over")
	},
	function(){
			$(".btn12").removeClass('over')
	});

	$(".btn13").hover(function(){
		$(".btn13").addClass("over")
	},
	function(){
			$(".btn13").removeClass('over')
	});

	$(".btn14").hover(function(){
		$(".btn14").addClass("over")
	},
	function(){
			$(".btn14").removeClass('over')
	});

	$(".btn15").hover(function(){
		$(".btn15").addClass("over")
	},
	function(){
			$(".btn15").removeClass('over')
	});

	$(".btn16").hover(function(){
		$(".btn16").addClass("over")
	},
	function(){
			$(".btn16").removeClass('over')
	});

	$(".btn17").hover(function(){
		$(".btn17").addClass("over")
	},
	function(){
			$(".btn17").removeClass('over')
	});

	$(".btn18").hover(function(){
		$(".btn18").addClass("over")
	},
	function(){
			$(".btn18").removeClass('over')
	});

	$("#btn1").hover(function(){
		$("#btn1").addClass("over")
	},
	function(){
			$("#btn1").removeClass('over')
	});	

	$("#btn2").hover(function(){
		$("#btn2").addClass("over")
	},
	function(){
			$("#btn2").removeClass('over')
	});

	$("#btn3").hover(function(){
		$("#btn3").addClass("over")
	},
	function(){
			$("#btn3").removeClass('over')
	});
	$("#btn4").hover(function(){
		$("#btn4").addClass("over")
	},
	function(){
			$("#btn4").removeClass('over')
	});

	});