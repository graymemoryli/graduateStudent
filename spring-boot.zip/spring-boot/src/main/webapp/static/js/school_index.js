		$(document).ready(function(){
			$("#a1").hover(function(){
				$("#a1").addClass("bg")
			},function(){
				$("#a1").removeClass("bg")
			});
			$("#a2").hover(function(){
				$("#a2").addClass("bg")
			},function(){
				$("#a2").removeClass("bg")
			});
			$("#a3").hover(function(){
				$("#a3").addClass("bg")
			},function(){
				$("#a3").removeClass("bg")
			});			
			$("#a4").hover(function(){
				$("#a4").addClass("bg")
			},function(){
				$("#a4").removeClass("bg")
			});
			$("#a5").hover(function(){
				$("#a5").addClass("bg")
			},function(){
				$("#a5").removeClass("bg")
			});
			$("#a6").hover(function(){
				$("#a6").addClass("bg")
			},function(){
				$("#a6").removeClass("bg")
			});
			$("#a7").hover(function(){
				$("#a7").addClass("bg")
			},function(){
				$("#a7").removeClass("bg")
			});	
			$("#a8").hover(function(){
				$("#a8").addClass("bg")
			},function(){
				$("#a8").removeClass("bg")
			});	
			$("#a9").hover(function(){
				$("#a9").addClass("bg")
			},function(){
				$("#a9").removeClass("bg")
			});	
			$("#a10").hover(function(){
				$("#a10").addClass("bg")
			},function(){
				$("#a10").removeClass("bg")
			});	
			$("#a11").hover(function(){
				$("#a11").addClass("bg")
			},function(){
				$("#a11").removeClass("bg")
			});
		});
	







