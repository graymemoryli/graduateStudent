package com.hwadee.train.sessionpram;

public class AdminSessionParam {

    public static final String ADMN_INFO ="adminindo";

}


