package com.hwadee.train.sessionpram;

public class InfoSessionParam {

    public static final String INFO = "info";
}
