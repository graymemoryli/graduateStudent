package com.hwadee.train.sessionpram;

public class ResumeSessionParam {

    public static final String RESUME_INFO ="resume";
}
