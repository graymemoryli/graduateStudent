package com.hwadee.train.sessionpram;

public class CompanySessionParam {

    public static final String COMPANY_INFO ="companydo";
}
