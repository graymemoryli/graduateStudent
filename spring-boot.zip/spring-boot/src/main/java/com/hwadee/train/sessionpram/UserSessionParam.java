package com.hwadee.train.sessionpram;

public class UserSessionParam {
    public static final String USER_INFO ="userdo";
}
